module.exports = [
  {
    "id": 0,
    "name": "Oleta Level",
    "phone_number": "+442032960159",
    "address": "10 London Wall, London EC2M 6SA, UK"
  },
  {
    "id": 1,
    "name": "Maida Harju",
    "phone_number": "+442032960899",
    "address": "Woodside House, 94 Tockholes Rd, Darwen BB3 1LL, UK"
  },
  {
    "id": 2,
    "name": "Lia Pigford",
    "phone_number": "+442032960182",
    "address": "23 Westmorland Cl, Darwen BB3 2TQ, UK"
  },
  {
    "id": 3,
    "name": "Ghislaine Darden",
    "phone_number": "+442032960427",
    "address": "20-24 Knowlesly Rd, Darwen BB3 2NE, UK"
  },
  {
    "id": 4,
    "name": "Jana Spitler",
    "phone_number": "+442032960370",
    "address": "4 St Lucia Cl, Darwen BB3 0SJ, UK"
  },
  {
    "id": 5,
    "name": "Dolly Detweiler",
    "phone_number": "+442032960977",
    "address": "18 Johnson Rd, Darwen BB3, UK"
  },
  {
    "id": 6,
    "name": "Stanley Vanderhoof",
    "phone_number": "+442032960000",
    "address": "17 Anchor Ave, Darwen BB3 0AZ, UK"
  },
  {
    "id": 7,
    "name": "Adan Milian",
    "phone_number": "+442032960011",
    "address": "20 Ellerbeck Rd, Darwen BB3 3EX, UK"
  },
  {
    "id": 8,
    "name": "Marivel Molina",
    "phone_number": "+442032960013",
    "address": "Tockholes Rd, Darwen BB3, UK"
  },
  {
    "id": 9,
    "name": "Kris Everett",
    "phone_number": "+442032960012",
    "address": "Pinewood, Tockholes Rd, Darwen BB3 1JY, UK"
  }
];
