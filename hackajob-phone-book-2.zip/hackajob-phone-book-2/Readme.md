### Readme

To boot up the app, follow these steps:

1. Run npm install in the console
2. Run nodemon to launch the app
3. Go to http://localhost:3000 to open the app
